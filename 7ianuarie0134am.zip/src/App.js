// App.js
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PrimaryPage from './PrimaryPage';
import MainApp from './MainApp';
import GoogleApp from './GoogleApp';
import Calendar from './Calendar';
import GoogleApp1 from './GoogleApp1';
function App() {
  const [userId, setUserId] = useState(0);

  const handleUserIdChange = (userId) => {
    setUserId(userId);
  };

  console.log(userId)

  return (
    <div>
      <Router>
        <Routes>
          <Route path="/" element={<PrimaryPage onUserIdChange={handleUserIdChange} />} />
          <Route path="/mainapp" element={<MainApp userId = {userId} />} />
          <Route path="/google-map" element={<GoogleApp userId = {userId}/>}  />
          <Route path="/google-map1" element={<GoogleApp1 userId = {userId}/>} />
          <Route path="/calendar" element={<Calendar />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
